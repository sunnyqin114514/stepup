import { useState } from "react";
import ProBadge from "../components/ProBadge";

type ReviewItem = {
  id: string;
  title: string;
  tag: string;
  due: string; // 第几次复习
  source: string;
};

const MOCK_REVIEWS: ReviewItem[] = [
  {
    id: "r1",
    title: "高频词根 -spect- 系列",
    tag: "英语",
    due: "第 2 次复习",
    source: "高频词根记忆法",
  },
  {
    id: "r2",
    title: "极限 ε-δ 定义",
    tag: "数学",
    due: "第 1 次复习",
    source: "极限定义易错点",
  },
  {
    id: "r3",
    title: "马原三大规律",
    tag: "政治",
    due: "第 3 次复习",
    source: "马原三大规律对比",
  },
];

const CURVE_POINTS = [
  { day: "第 1 天", retention: 100 },
  { day: "第 2 天", retention: 36 },
  { day: "第 4 天", retention: 28 },
  { day: "第 7 天", retention: 25 },
  { day: "第 15 天", retention: 21 },
  { day: "第 30 天", retention: 18 },
];

export default function ReviewPage() {
  const [showComingSoon, setShowComingSoon] = useState(false);
  const [picked, setPicked] = useState<string | null>(null);

  const handlePick = (level: "remember" | "fuzzy" | "forgot") => {
    setPicked(level);
    setShowComingSoon(true);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900">复习提醒</h1>
            <ProBadge />
          </div>
          <p className="text-sm text-slate-500 mt-1">
            基于艾宾浩斯遗忘曲线，在最佳时机提醒你复习。
          </p>
        </div>
      </div>

      {/* 遗忘曲线 */}
      <div className="card p-5 mb-6">
        <h2 className="font-semibold text-slate-900 mb-1">
          艾宾浩斯遗忘曲线
        </h2>
        <p className="text-xs text-slate-500 mb-4">
          越接近遗忘点复习，记忆越牢固。
        </p>
        <svg viewBox="0 0 320 140" className="w-full h-36">
          {/* 坐标轴 */}
          <line x1="30" y1="110" x2="310" y2="110" stroke="#e2e8f0" />
          <line x1="30" y1="10" x2="30" y2="110" stroke="#e2e8f0" />
          {/* 曲线 */}
          {(() => {
            const max = 100;
            const w = 280 / (CURVE_POINTS.length - 1);
            const pts = CURVE_POINTS.map((p, i) => {
              const x = 30 + i * w;
              const y = 110 - (p.retention / max) * 100;
              return { x, y, p };
            });
            const path = pts
              .map((pt, i) =>
                i === 0 ? `M${pt.x},${pt.y}` : `L${pt.x},${pt.y}`
              )
              .join(" ");
            return (
              <>
                <path
                  d={path}
                  fill="none"
                  stroke="#f59e0b"
                  strokeWidth="2.5"
                />
                {pts.map((pt) => (
                  <g key={pt.p.day}>
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r="3.5"
                      fill="#f59e0b"
                    />
                    <text
                      x={pt.x}
                      y={pt.y - 8}
                      textAnchor="middle"
                      className="fill-amber-600"
                      style={{ fontSize: 9 }}
                    >
                      {pt.p.retention}%
                    </text>
                    <text
                      x={pt.x}
                      y={125}
                      textAnchor="middle"
                      className="fill-slate-400"
                      style={{ fontSize: 9 }}
                    >
                      {pt.p.day}
                    </text>
                  </g>
                ))}
              </>
            );
          })()}
        </svg>
      </div>

      {/* 今日待复习 */}
      <div className="mb-3 flex items-center justify-between">
        <h2 className="font-semibold text-slate-900">今日待复习</h2>
        <span className="text-xs text-slate-500">
          {MOCK_REVIEWS.length} 条
        </span>
      </div>
      <div className="space-y-2">
        {MOCK_REVIEWS.map((r) => (
          <div key={r.id} className="card p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 text-xs">
                    {r.tag}
                  </span>
                  <span className="text-xs text-slate-400">{r.due}</span>
                </div>
                <h3 className="font-medium text-slate-900 truncate">
                  {r.title}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  来源：{r.source}
                </p>
              </div>
              <div className="flex gap-1.5 shrink-0">
                <button
                  onClick={() => handlePick("remember")}
                  className="px-3 py-1.5 rounded-lg text-xs bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition"
                >
                  记得
                </button>
                <button
                  onClick={() => handlePick("fuzzy")}
                  className="px-3 py-1.5 rounded-lg text-xs bg-amber-50 text-amber-600 hover:bg-amber-100 transition"
                >
                  模糊
                </button>
                <button
                  onClick={() => handlePick("forgot")}
                  className="px-3 py-1.5 rounded-lg text-xs bg-rose-50 text-rose-600 hover:bg-rose-100 transition"
                >
                  忘了
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showComingSoon && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
          onClick={() => {
            setShowComingSoon(false);
            setPicked(null);
          }}
        >
          <div
            className="card p-6 max-w-sm text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-3xl mb-2">🚧</div>
            <h3 className="font-semibold text-slate-900 mb-1">
              功能开发中
            </h3>
            <p className="text-sm text-slate-500">
              你选择了「
              {picked === "remember"
                ? "记得"
                : picked === "fuzzy"
                ? "模糊"
                : "忘了"}
              」。复习进度记录与下次排期功能正在路上，敬请期待。
            </p>
            <button
              className="btn-primary mt-4"
              onClick={() => {
                setShowComingSoon(false);
                setPicked(null);
              }}
            >
              知道了
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
