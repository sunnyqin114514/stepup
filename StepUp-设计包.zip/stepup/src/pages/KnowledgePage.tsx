import { useState } from "react";
import ProBadge from "../components/ProBadge";

type Note = {
  id: string;
  tag: string;
  title: string;
  excerpt: string;
  relatedTask: string;
  date: string;
};

const MOCK_NOTES: Note[] = [
  {
    id: "n1",
    tag: "英语",
    title: "高频词根记忆法",
    excerpt:
      "把 -spect- 系列词（inspect、respect、suspect）放在一起记，比单独背效率高 3 倍。",
    relatedTask: "英语单词 100 个",
    date: "2026-07-16",
  },
  {
    id: "n2",
    tag: "数学",
    title: "极限定义易错点",
    excerpt:
      "ε-δ 定义里 δ 依赖 ε，不要写成 δ 是常数。考研真题里常考这个细节。",
    relatedTask: "高数基础 1 小时",
    date: "2026-07-16",
  },
  {
    id: "n3",
    tag: "政治",
    title: "马原三大规律对比",
    excerpt:
      "对立统一是核心，量变质变是过程，否定之否定是方向。三者别混。",
    relatedTask: "政治基础梳理",
    date: "2026-07-17",
  },
  {
    id: "n4",
    tag: "英语",
    title: "长难句拆分三步法",
    excerpt: "找主谓 → 划从句 → 翻译主干，剩下的修饰成分逐个补回。",
    relatedTask: "英语阅读 2 篇",
    date: "2026-07-17",
  },
  {
    id: "n5",
    tag: "数学",
    title: "中值定理使用条件",
    excerpt:
      "罗尔需要闭区间连续、开区间可导且端点值相等；拉格朗日不要求端点相等。",
    relatedTask: "高数强化 1.5 小时",
    date: "2026-07-18",
  },
];

const TAGS = ["全部", "英语", "数学", "政治"];

export default function KnowledgePage() {
  const [activeTag, setActiveTag] = useState("全部");
  const [showComingSoon, setShowComingSoon] = useState(false);

  const filtered =
    activeTag === "全部"
      ? MOCK_NOTES
      : MOCK_NOTES.filter((n) => n.tag === activeTag);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900">个人知识库</h1>
            <ProBadge />
          </div>
          <p className="text-sm text-slate-500 mt-1">
            执行中沉淀笔记、错题与心得，关联到具体任务。
          </p>
        </div>
        <button
          className="btn-primary"
          onClick={() => setShowComingSoon(true)}
        >
          + 新增笔记
        </button>
      </div>

      {/* 标签筛选 */}
      <div className="flex gap-2 mb-5 overflow-x-auto pb-1">
        {TAGS.map((t) => (
          <button
            key={t}
            onClick={() => setActiveTag(t)}
            className={`px-3 py-1.5 rounded-lg text-sm whitespace-nowrap border transition ${
              activeTag === t
                ? "bg-brand-50 border-brand-300 text-brand-600"
                : "bg-white border-slate-200 text-slate-600 hover:border-brand-200"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {/* 笔记列表 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map((n) => (
          <div key={n.id} className="card p-4 hover:shadow-md transition">
            <div className="flex items-center justify-between mb-2">
              <span className="px-2 py-0.5 rounded-full bg-violet-50 text-violet-600 text-xs">
                {n.tag}
              </span>
              <span className="text-xs text-slate-400">{n.date}</span>
            </div>
            <h3 className="font-semibold text-slate-900 mb-1">{n.title}</h3>
            <p className="text-sm text-slate-600 line-clamp-2">
              {n.excerpt}
            </p>
            <div className="mt-3 text-xs text-slate-400">
              关联任务：{n.relatedTask}
            </div>
          </div>
        ))}
      </div>

      {/* 待开发提示 */}
      {showComingSoon && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
          onClick={() => setShowComingSoon(false)}
        >
          <div
            className="card p-6 max-w-sm text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-3xl mb-2">🚧</div>
            <h3 className="font-semibold text-slate-900 mb-1">
              功能开发中
            </h3>
            <p className="text-sm text-slate-500">
              知识库的新增、编辑与 AI 关联功能正在路上，敬请期待。
            </p>
            <button
              className="btn-primary mt-4"
              onClick={() => setShowComingSoon(false)}
            >
              知道了
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
