import { useMemo } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  computeAchievement,
  getOverallProgress,
  getPendingBacklog,
  getTodayTasksFromWorkspace,
  getTomorrowTasksFromWorkspace,
  loadReviews,
  loadWorkspace,
  todayStr,
} from "../lib/storage";
import { SKIP_REASON_LABELS, type ReviewLog } from "../types/plan";

export default function ProgressPage() {
  const location = useLocation();
  const ws = useMemo(() => loadWorkspace(), [location.key]);
  const reviews = useMemo(() => loadReviews(), [location.key]);
  const backlog = useMemo(() => getPendingBacklog(), [location.key]);
  const today = todayStr();

  const achievement = useMemo(
    () => computeAchievement(ws, reviews),
    [ws, reviews]
  );

  const todayReview: ReviewLog | null = useMemo(() => {
    const list = reviews.filter((r) => r.date === today);
    return list.at(-1) ?? null;
  }, [reviews, today]);

  const todayTasks = getTodayTasksFromWorkspace(ws);
  const tomorrowTasks = getTomorrowTasksFromWorkspace(ws);
  const progress = getOverallProgress(ws);
  const hasData =
    ws.plans.length > 0 || ws.adhocTasks.length > 0 || reviews.length > 0;

  if (!hasData) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16 text-center">
        <div className="text-slate-500 mb-4">还没有学习记录</div>
        <Link to="/schedule" className="btn-primary">
          进入学习日
        </Link>
      </div>
    );
  }

  const completedToday =
    todayReview?.completedCount ??
    todayTasks.filter((t) => t.completed).length;
  const totalToday = todayReview?.totalCount ?? todayTasks.length;
  const focusMinutes =
    todayReview?.focusMinutes ??
    Math.round(todayTasks.reduce((s, t) => s + t.focusSeconds, 0) / 60);
  const rate =
    totalToday > 0 ? Math.round((completedToday / totalToday) * 100) : 0;
  const activeGoals = ws.plans.filter(
    (p) => (p.status ?? "active") === "active"
  );

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">每日复盘</h1>
          <p className="text-sm text-slate-500 mt-1">
            总结今天做得怎么样。未完成在池子里，明天由你选择是否加入学习日。
          </p>
        </div>
        <Link to="/schedule" className="btn-primary shrink-0">
          查看学习日
        </Link>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <StatCard
          label="今日完成"
          value={`${completedToday}/${totalToday}`}
          accent="text-brand-600"
        />
        <StatCard
          label="今日专注"
          value={`${focusMinutes} 分钟`}
          accent="text-emerald-600"
        />
        <StatCard label="完成率" value={`${rate}%`} accent="text-violet-600" />
        <StatCard
          label="连续天数"
          value={`${achievement.streakDays} 天`}
          accent="text-amber-600"
        />
      </div>

      <div className="card p-5 mb-4">
        <h2 className="font-semibold text-slate-900 mb-2">今日总结</h2>
        <p className="text-sm text-slate-600">
          进行中目标：
          {activeGoals.length === 0
            ? "无（今日可能只有临时任务）"
            : activeGoals.map((g) => g.goal).join("、")}
        </p>
        {todayReview?.aiSuggestion ? (
          <p className="mt-3 text-sm text-emerald-700 bg-emerald-50 rounded-lg px-3 py-2">
            {todayReview.aiSuggestion}
          </p>
        ) : (
          <p className="mt-3 text-sm text-slate-500">
            今天还没有收工记录。去学习日完成任务或点「累了，明天再搞」后，这里会显示总结。
          </p>
        )}
      </div>

      <div className="card p-5 mb-4">
        <h2 className="font-semibold text-slate-900 mb-3">未完成与原因</h2>
        {todayReview && todayReview.unfinishedTitles?.length > 0 ? (
          <div className="space-y-2">
            {todayReview.unfinishedTitles.map((title) => (
              <div
                key={title}
                className="flex items-center justify-between text-sm rounded-lg bg-slate-50 px-3 py-2"
              >
                <span className="text-slate-700">{title}</span>
                <span className="text-xs text-amber-600">
                  {todayReview.reason
                    ? SKIP_REASON_LABELS[todayReview.reason]
                    : "已记录"}
                </span>
              </div>
            ))}
            {todayReview.difficulty && (
              <p className="text-xs text-slate-500 mt-2">
                备注：{todayReview.difficulty}
              </p>
            )}
          </div>
        ) : completedToday === totalToday && totalToday > 0 ? (
          <p className="text-sm text-emerald-600">今日全部完成，没有未完成项。</p>
        ) : (
          <p className="text-sm text-slate-500">
            暂无收工记录。若今日有未完成任务，请在学习日点「累了，明天再搞」。
          </p>
        )}
      </div>

      <div className="card p-5 mb-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-900">未完成池</h2>
          <span className="text-xs text-slate-400">{backlog.length} 条待处理</span>
        </div>
        {backlog.length === 0 ? (
          <p className="text-sm text-slate-500">池子是空的，很好。</p>
        ) : (
          <div className="space-y-2">
            {backlog.slice(0, 8).map((b) => (
              <div
                key={b.id}
                className="text-sm rounded-lg border border-slate-100 px-3 py-2"
              >
                <div className="font-medium text-slate-800">{b.title}</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  {b.goalTitle || "临时"} · {b.sourceDate} ·{" "}
                  {SKIP_REASON_LABELS[b.reason]}
                </div>
              </div>
            ))}
            <p className="text-xs text-slate-400 pt-1">
              下次进入学习日时，可逐条选择「加入今日 / 先放着 / 放弃」。
            </p>
          </div>
        )}
      </div>

      <div className="card p-5 mb-4">
        <h2 className="font-semibold text-slate-900 mb-3">明日预告</h2>
        {tomorrowTasks.length === 0 ? (
          <p className="text-sm text-slate-500">
            明天暂无已排任务。未完成池项目可在明天选择加入。
          </p>
        ) : (
          <ul className="space-y-1.5">
            {tomorrowTasks.map((t) => (
              <li
                key={t.id}
                className="text-sm text-slate-700 flex justify-between gap-2"
              >
                <span>
                  <span className="text-xs text-slate-400 mr-2">
                    {t.goalTitle || "临时"}
                  </span>
                  {t.title}
                </span>
                <span className="text-xs text-slate-400 shrink-0">
                  {t.suggestedMinutes} 分
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="card p-5 mb-6">
        <h2 className="font-semibold text-slate-900 mb-3">里程碑徽章</h2>
        <div className="grid grid-cols-3 gap-3">
          {[
            { k: "milestone25" as const, l: "25% 起步", e: "🏆" },
            { k: "milestone50" as const, l: "50% 过半", e: "🥈" },
            { k: "milestone100" as const, l: "100% 达成", e: "🥇" },
          ].map((m) => {
            const unlocked = achievement[m.k];
            return (
              <div
                key={m.k}
                className={`rounded-xl p-4 text-center border transition ${
                  unlocked
                    ? "bg-amber-50 border-amber-200"
                    : "bg-slate-50 border-slate-100 opacity-60"
                }`}
              >
                <div className="text-2xl mb-1">{m.e}</div>
                <div className="text-xs text-slate-700">{m.l}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {unlocked ? "已解锁" : "未解锁"}
                </div>
              </div>
            );
          })}
        </div>
        <div className="text-xs text-slate-400 mt-3 text-center">
          整体进度 {Math.round(progress * 100)}% · 累计专注{" "}
          {achievement.totalFocusMinutes} 分钟
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Link to="/schedule" className="btn-primary">
          查看学习日
        </Link>
        <Link to="/planner" className="btn-ghost">
          去规划页
        </Link>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  accent,
}: {
  label: string;
  value: string;
  accent: string;
}) {
  return (
    <div className="card p-4">
      <div className="text-xs text-slate-500">{label}</div>
      <div className={`text-xl font-bold mt-1 ${accent}`}>{value}</div>
    </div>
  );
}
