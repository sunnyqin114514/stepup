import { useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { decomposePlan, replanPlan } from "../services/planApi";
import {
  canAddActiveGoal,
  canDecompose,
  canReplan,
  FREE_DECOMPOSE_LIMIT,
  FREE_REPLAN_LIMIT,
  getActivePlans,
  getAiUsage,
  incrementDecomposeCount,
  incrementReplanCount,
  isProUnlocked,
  loadWorkspace,
  removePlan,
  setActivePlanId,
  setPlanStatus,
  todayStr,
  uid,
  upsertPlan,
} from "../lib/storage";
import type { Plan, TaskItem, Workspace } from "../types/plan";
import { FREE_ACTIVE_GOAL_LIMIT } from "../types/plan";
import TaskCard from "../components/TaskCard";

function groupByDate(tasks: TaskItem[]): Record<string, TaskItem[]> {
  const map: Record<string, TaskItem[]> = {};
  for (const t of tasks) {
    (map[t.date] ??= []).push(t);
  }
  return map;
}

export default function PlannerPage() {
  const navigate = useNavigate();
  const [ws, setWs] = useState<Workspace>(() => loadWorkspace());
  const activePlan =
    ws.plans.find((p) => p.id === ws.activePlanId) ?? ws.plans[0] ?? null;

  const [goal, setGoal] = useState(activePlan?.goal ?? "");
  const [deadline, setDeadline] = useState(activePlan?.deadline ?? "");
  const [dailyMinutes, setDailyMinutes] = useState(
    activePlan?.dailyMinutes ?? 120
  );
  const [workdays, setWorkdays] = useState<string[]>(
    activePlan?.workdays ?? ["weekday", "weekend"]
  );
  const [loading, setLoading] = useState(false);
  const [adjusting, setAdjusting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mockNotice, setMockNotice] = useState(false);
  const [adjustNote, setAdjustNote] = useState("");
  const [creatingNew, setCreatingNew] = useState(false);

  const plan = creatingNew ? null : activePlan;

  const grouped = useMemo(
    () => (plan ? groupByDate(plan.tasks) : {}),
    [plan]
  );
  const sortedDates = useMemo(() => Object.keys(grouped).sort(), [grouped]);
  const activeCount = getActivePlans(ws).length;
  const pro = isProUnlocked();

  const selectPlan = (planId: string) => {
    setCreatingNew(false);
    const next = setActivePlanId(planId);
    setWs(next);
    const p = next.plans.find((x) => x.id === planId);
    if (p) {
      setGoal(p.goal);
      setDeadline(p.deadline);
      setDailyMinutes(p.dailyMinutes);
      setWorkdays(p.workdays);
    }
  };

  const startNewGoal = () => {
    if (!canAddActiveGoal(ws)) {
      setError(
        `免费版最多 ${FREE_ACTIVE_GOAL_LIMIT} 个进行中目标。请升级 Pro，或先暂停/完成现有目标。`
      );
      return;
    }
    setCreatingNew(true);
    setGoal("");
    setDeadline("");
    setDailyMinutes(120);
    setWorkdays(["weekday", "weekend"]);
    setError(null);
    setMockNotice(false);
  };

  const toggleWorkday = (w: string) => {
    setWorkdays((prev) =>
      prev.includes(w) ? prev.filter((x) => x !== w) : [...prev, w]
    );
  };

  const handleDecompose = async () => {
    setError(null);
    if (!goal.trim()) {
      setError("请输入你的大目标");
      return;
    }
    if (!deadline) {
      setError("请选择截止日期");
      return;
    }
    if (deadline <= todayStr()) {
      setError("截止日期必须晚于今天");
      return;
    }

    // 新建时检查配额
    if (creatingNew && !canAddActiveGoal(ws)) {
      setError(
        `免费版最多 ${FREE_ACTIVE_GOAL_LIMIT} 个进行中目标，请升级 Pro。`
      );
      return;
    }

    // AI 拆解次数检查（免费版每天 3 次）
    if (!canDecompose()) {
      setError(
        `今日 AI 拆解次数已用完（免费版每天 ${FREE_DECOMPOSE_LIMIT} 次）。升级 Pro 可无限使用。`
      );
      return;
    }

    setLoading(true);
    try {
      const res = await decomposePlan({
        goal: goal.trim(),
        deadline,
        dailyMinutes,
        workdays,
      });

      const planId = creatingNew || !plan ? uid() : plan.id;
      const tasks: TaskItem[] = res.tasks.map((t) => ({
        ...t,
        id: uid(),
        completed: false,
        focusSeconds: 0,
        source: "goal" as const,
        goalId: planId,
      }));

      const newPlan: Plan = {
        id: planId,
        goal: goal.trim(),
        deadline,
        dailyMinutes,
        workdays: workdays as Plan["workdays"],
        createdAt: creatingNew || !plan ? new Date().toISOString() : plan.createdAt,
        tasks:
          creatingNew || !plan
            ? tasks
            : [
                ...plan.tasks.filter((t) => t.completed),
                ...tasks,
              ],
        status: "active",
      };

      // 重新拆解未完成：若非新建，用 AI 结果替换未完成
      if (!creatingNew && plan) {
        newPlan.tasks = [
          ...plan.tasks.filter((t) => t.completed),
          ...tasks,
        ];
      }

      const next = upsertPlan(newPlan);
      setWs(next);
      setCreatingNew(false);
      incrementDecomposeCount();
      setMockNotice(Boolean(res.mock));
      // 拆解成功 → 跳转学习日（高动机时刻落地）
      navigate("/schedule", {
        state: { decomposeSuccess: true, taskCount: tasks.length },
      });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "AI 调用失败";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  const handleAdjust = async () => {
    if (!plan) return;
    setError(null);
    // AI 重排次数检查（免费版每天 1 次）
    if (!canReplan()) {
      setError(
        `今日 AI 重排次数已用完（免费版每天 ${FREE_REPLAN_LIMIT} 次）。升级 Pro 可无限使用。`
      );
      return;
    }
    setAdjusting(true);
    try {
      const res = await replanPlan({
        plan,
        difficulty: adjustNote.trim() || "用户主动请求调整日程",
        tomorrowMinutes: dailyMinutes,
      });
      const completedTasks = plan.tasks.filter((t) => t.completed);
      const newTasks: TaskItem[] = res.tasks.map((t) => ({
        ...t,
        id: uid(),
        completed: false,
        focusSeconds: 0,
        source: "goal" as const,
        goalId: plan.id,
      }));
      const nextPlan: Plan = {
        ...plan,
        dailyMinutes,
        tasks: [...completedTasks, ...newTasks],
      };
      setWs(upsertPlan(nextPlan));
      incrementReplanCount();
      setMockNotice(Boolean(res.mock));
      setAdjustNote("");
    } catch (e) {
      const msg = e instanceof Error ? e.message : "调整失败";
      setError(msg);
    } finally {
      setAdjusting(false);
    }
  };

  const handleToggle = (id: string) => {
    if (!plan) return;
    const tasks = plan.tasks.map((t) =>
      t.id === id ? { ...t, completed: !t.completed } : t
    );
    setWs(upsertPlan({ ...plan, tasks }));
  };

  const handleEdit = (id: string, patch: Partial<TaskItem>) => {
    if (!plan) return;
    const tasks = plan.tasks.map((t) =>
      t.id === id ? { ...t, ...patch } : t
    );
    setWs(upsertPlan({ ...plan, tasks }));
  };

  const handlePause = () => {
    if (!plan) return;
    setWs(setPlanStatus(plan.id, "paused"));
  };

  const handleResume = (planId: string) => {
    if (!canAddActiveGoal(ws) && !pro) {
      const target = ws.plans.find((p) => p.id === planId);
      if (target && (target.status ?? "active") !== "active") {
        setError(
          `免费版最多 ${FREE_ACTIVE_GOAL_LIMIT} 个进行中目标。请先暂停其他目标，或升级 Pro。`
        );
        return;
      }
    }
    // 若当前激活数已满且目标不是 active，拦截
    const target = ws.plans.find((p) => p.id === planId);
    if (
      target &&
      (target.status ?? "active") !== "active" &&
      !canAddActiveGoal(ws)
    ) {
      setError(
        `免费版最多 ${FREE_ACTIVE_GOAL_LIMIT} 个进行中目标。请升级 Pro。`
      );
      return;
    }
    setWs(setPlanStatus(planId, "active"));
    selectPlan(planId);
  };

  const handleDelete = () => {
    if (!plan) return;
    if (!confirm(`确定删除目标「${plan.goal}」？任务将一并删除。`)) return;
    const next = removePlan(plan.id);
    setWs(next);
    const p = next.plans.find((x) => x.id === next.activePlanId);
    if (p) {
      setGoal(p.goal);
      setDeadline(p.deadline);
      setDailyMinutes(p.dailyMinutes);
      setWorkdays(p.workdays);
      setCreatingNew(false);
    } else {
      setCreatingNew(true);
      setGoal("");
      setDeadline("");
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">目标规划</h1>
          <p className="text-sm text-slate-500 mt-1">
            管理多个大目标与长期排期。日常执行去「学习日」，也可在那里加临时任务。
          </p>
        </div>
        <Link to="/schedule" className="btn-primary shrink-0">
          进入学习日
        </Link>
      </div>

      {/* AI 用量进度 */}
      {pro ? (
        <div className="card p-3 mb-4 flex items-center gap-2 text-sm text-amber-700 bg-amber-50/50">
          <span>✨</span>
          <span>Pro 会员 · 无限 AI 拆解/重排</span>
        </div>
      ) : (
        (() => {
          const usage = getAiUsage();
          return (
            <div className="card p-3 mb-4 flex items-center gap-3">
              <span className="text-xs text-slate-500 shrink-0">
                今日 AI 拆解
              </span>
              <div className="flex-1 h-2 rounded-full bg-slate-100 overflow-hidden">
                <div
                  className="h-full bg-brand-500 transition-all"
                  style={{
                    width: `${Math.min(100, (usage.decomposeUsed / FREE_DECOMPOSE_LIMIT) * 100)}%`,
                  }}
                />
              </div>
              <span className="text-xs font-medium text-slate-600 shrink-0">
                {usage.decomposeUsed}/{FREE_DECOMPOSE_LIMIT} 已用
              </span>
            </div>
          );
        })()
      )}

      {/* 多目标列表 */}
      <div className="card p-4 mb-6">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="font-semibold text-slate-900">我的大目标</h2>
            <p className="text-xs text-slate-400 mt-0.5">
              进行中 {activeCount} 个
              {!pro && ` · 免费版上限 ${FREE_ACTIVE_GOAL_LIMIT} 个`}
              {pro && " · Pro 不限数量"}
            </p>
          </div>
          <button className="btn-ghost text-sm py-1.5" onClick={startNewGoal}>
            + 新建目标
          </button>
        </div>

        {ws.plans.length === 0 && !creatingNew ? (
          <p className="text-sm text-slate-500 py-2">
            还没有大目标。点击「新建目标」开始 AI 拆解。
          </p>
        ) : (
          <div className="flex flex-wrap gap-2">
            {ws.plans.map((p) => {
              const active = !creatingNew && plan?.id === p.id;
              const paused = (p.status ?? "active") === "paused";
              return (
                <button
                  key={p.id}
                  onClick={() =>
                    paused ? handleResume(p.id) : selectPlan(p.id)
                  }
                  className={`px-3 py-2 rounded-xl text-sm border text-left transition max-w-[220px] ${
                    active
                      ? "bg-brand-50 border-brand-300 text-brand-700"
                      : paused
                      ? "bg-slate-50 border-slate-200 text-slate-400"
                      : "bg-white border-slate-200 text-slate-700 hover:border-brand-200"
                  }`}
                >
                  <div className="font-medium truncate">{p.goal}</div>
                  <div className="text-[10px] mt-0.5">
                    {paused ? "已暂停 · 点击恢复" : `截止 ${p.deadline}`}
                  </div>
                </button>
              );
            })}
            {creatingNew && (
              <span className="px-3 py-2 rounded-xl text-sm border border-dashed border-brand-300 bg-brand-50/50 text-brand-600">
                新建中…
              </span>
            )}
          </div>
        )}

        {!pro && activeCount >= FREE_ACTIVE_GOAL_LIMIT && (
          <p className="text-xs text-amber-600 mt-3">
            已达免费版上限。
            <Link to="/membership" className="underline ml-1">
              升级 Pro
            </Link>
            可同时推进多个大目标。
          </p>
        )}
      </div>

      <div className="card p-5 mb-6">
        <label className="block text-sm font-medium text-slate-700 mb-1">
          {creatingNew ? "新增大目标" : "当前大目标"}
        </label>
        <input
          className="input-field mb-4"
          placeholder="如：3 个月考研 / 1 个月学完 Python"
          value={goal}
          onChange={(e) => setGoal(e.target.value)}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              截止日期
            </label>
            <input
              type="date"
              className="input-field"
              value={deadline}
              min={todayStr()}
              onChange={(e) => setDeadline(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">
              每天可投入时长（分钟）
            </label>
            <input
              type="number"
              min={15}
              max={600}
              className="input-field"
              value={dailyMinutes}
              onChange={(e) =>
                setDailyMinutes(Number(e.target.value) || 60)
              }
            />
          </div>
        </div>

        <div className="mt-4">
          <label className="block text-sm font-medium text-slate-700 mb-2">
            可执行日
          </label>
          <div className="flex gap-2">
            {[
              { v: "weekday", l: "工作日" },
              { v: "weekend", l: "周末" },
            ].map((w) => (
              <button
                key={w.v}
                onClick={() => toggleWorkday(w.v)}
                className={`px-4 py-1.5 rounded-lg text-sm border transition ${
                  workdays.includes(w.v)
                    ? "bg-brand-50 border-brand-300 text-brand-600"
                    : "bg-white border-slate-200 text-slate-600"
                }`}
              >
                {w.l}
              </button>
            ))}
          </div>
        </div>

        {error && (
          <div className="mt-4 rounded-lg bg-rose-50 text-rose-600 text-sm px-3 py-2">
            {error}
          </div>
        )}

        {mockNotice && (
          <div className="mt-4 rounded-lg bg-amber-50 text-amber-700 text-sm px-3 py-2">
            演示模式：当前为示例/兜底数据。配置 DeepSeek key 后将使用真实 AI。
          </div>
        )}

        <div className="mt-5 flex flex-wrap items-center gap-3">
          <button
            className="btn-primary"
            disabled={loading}
            onClick={handleDecompose}
          >
            {loading
              ? "AI 拆解中…"
              : creatingNew || !plan
              ? "AI 拆解"
              : "重新拆解"}
          </button>
          <Link to="/schedule" className="btn-ghost">
            进入学习日
          </Link>
          {plan && !creatingNew && (
            <>
              <button className="btn-ghost" onClick={handlePause}>
                暂停此目标
              </button>
              <button
                className="text-sm text-rose-500 hover:underline"
                onClick={handleDelete}
              >
                删除
              </button>
            </>
          )}
          {creatingNew && ws.plans.length > 0 && (
            <button
              className="btn-ghost"
              onClick={() => {
                setCreatingNew(false);
                if (activePlan) selectPlan(activePlan.id);
              }}
            >
              取消新建
            </button>
          )}
        </div>
      </div>

      {plan && !creatingNew && (
        <>
          <div className="card p-5 mb-6">
            <h2 className="font-semibold text-slate-900 mb-1">调整日程</h2>
            <p className="text-xs text-slate-500 mb-3">
              主动请求 AI 重新安排本目标的未完成任务。日常收工不会走这里。
            </p>
            <textarea
              className="input-field min-h-[64px] mb-3"
              placeholder="例如：想把节奏放慢 / 数学部分提前"
              value={adjustNote}
              onChange={(e) => setAdjustNote(e.target.value)}
            />
            <button
              className="btn-ghost"
              disabled={adjusting}
              onClick={handleAdjust}
            >
              {adjusting ? "调整中…" : "AI 调整日程"}
            </button>
          </div>

          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-semibold text-slate-900">
              {plan.goal}
            </h2>
            <span className="text-xs text-slate-400">
              {plan.tasks.length} 个任务 · 可编辑
            </span>
          </div>

          {sortedDates.length === 0 && (
            <div className="text-sm text-slate-500 py-8 text-center">
              暂无任务
            </div>
          )}

          <div className="space-y-6">
            {sortedDates.map((date) => (
              <div key={date}>
                <div className="text-xs font-medium text-slate-500 mb-2 px-1">
                  {date}
                </div>
                <div className="space-y-2">
                  {grouped[date].map((t) => (
                    <TaskCard
                      key={t.id}
                      task={t}
                      goalLabel={plan.goal}
                      onToggleComplete={handleToggle}
                      onEdit={handleEdit}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
