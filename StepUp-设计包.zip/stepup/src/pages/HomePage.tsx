import { Link } from "react-router-dom";
import ProBadge from "../components/ProBadge";

const FEATURES = [
  {
    to: "/planner",
    title: "AI 任务拆解",
    desc: "输入大目标，AI 拆成每日可执行任务",
    accent: "from-brand-400 to-brand-600",
    preview: (
      <div className="space-y-2 text-left">
        <div className="text-[10px] text-slate-400">目标</div>
        <div className="h-7 rounded-md bg-slate-100 flex items-center px-2 text-xs text-slate-500">
          3 个月考研
        </div>
        <div className="text-[10px] text-slate-400">第 1 天</div>
        <div className="space-y-1">
          {["通读考研大纲", "英语单词 100 个", "高数基础 1 小时"].map((t) => (
            <div
              key={t}
              className="flex items-center gap-2 text-xs text-slate-600"
            >
              <span className="w-3 h-3 rounded border border-slate-300" />
              {t}
            </div>
          ))}
        </div>
      </div>
    ),
  },
  {
    to: "/schedule",
    title: "学习日",
    desc: "今天做什么：大目标任务 + 临时任务",
    accent: "from-emerald-400 to-emerald-600",
    preview: (
      <div className="flex items-center gap-3">
        <div className="relative w-16 h-16">
          <svg viewBox="0 0 36 36" className="w-16 h-16 -rotate-90">
            <circle
              cx="18"
              cy="18"
              r="15"
              fill="none"
              stroke="#e2e8f0"
              strokeWidth="3"
            />
            <circle
              cx="18"
              cy="18"
              r="15"
              fill="none"
              stroke="#10b981"
              strokeWidth="3"
              strokeDasharray="60 100"
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-emerald-600">
            60%
          </div>
        </div>
        <div className="flex-1 text-left">
          <div className="text-xs text-slate-500">今日任务</div>
          <div className="font-mono text-lg text-slate-900">3/5</div>
          <div className="text-[10px] text-emerald-500">进入学习日</div>
        </div>
      </div>
    ),
  },
  {
    to: "/knowledge",
    title: "个人知识库",
    desc: "执行中沉淀笔记、错题与心得",
    accent: "from-violet-400 to-violet-600",
    pro: true,
    preview: (
      <div className="space-y-1.5 text-left">
        {[
          { tag: "英语", title: "高频词根记忆法" },
          { tag: "数学", title: "极限定义易错点" },
          { tag: "政治", title: "马原三大规律对比" },
        ].map((n) => (
          <div
            key={n.title}
            className="flex items-center gap-2 text-xs text-slate-600"
          >
            <span className="px-1.5 py-0.5 rounded bg-violet-50 text-violet-600 text-[10px]">
              {n.tag}
            </span>
            <span className="truncate">{n.title}</span>
          </div>
        ))}
      </div>
    ),
  },
  {
    to: "/review",
    title: "复习提醒",
    desc: "艾宾浩斯曲线，在最佳时机提醒你",
    accent: "from-amber-400 to-orange-500",
    pro: true,
    preview: (
      <div className="text-left">
        <svg viewBox="0 0 120 50" className="w-full h-12">
          <path
            d="M5 8 Q 25 8, 35 22 T 70 32 T 115 38"
            fill="none"
            stroke="#f59e0b"
            strokeWidth="2"
          />
          {[10, 35, 70, 115].map((x) => (
            <circle key={x} cx={x} cy={x === 10 ? 8 : x === 35 ? 22 : x === 70 ? 32 : 38} r="2.5" fill="#f59e0b" />
          ))}
        </svg>
        <div className="text-[10px] text-slate-400 mt-1">今日待复习 3 条</div>
      </div>
    ),
  },
];

export default function HomePage() {
  return (
    <div className="bg-gradient-to-b from-brand-50 via-white to-white">
      {/* Hero */}
      <section className="max-w-6xl mx-auto px-4 pt-16 pb-12 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white border border-brand-100 text-xs text-brand-600 shadow-sm mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-brand-500 animate-pulse" />
          AI 驱动的目标执行工具
        </div>
        <h1 className="text-4xl md:text-6xl font-bold tracking-tight text-slate-900">
          把大目标，
          <br />
          <span className="bg-gradient-to-r from-brand-500 to-brand-700 bg-clip-text text-transparent">
            变成今天做得到的小事
          </span>
        </h1>
        <p className="mt-6 text-base md:text-lg text-slate-600 max-w-2xl mx-auto">
          告诉 StepUp 你的目标与截止日期，AI 拆解为每日任务；
          配合专注计时、知识沉淀与复习提醒，让每天的努力都有迹可循。
        </p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link to="/schedule" className="btn-primary">
            进入学习日
          </Link>
          <Link to="/planner" className="btn-ghost">
            开始拆解目标
          </Link>
          <Link to="/membership" className="btn-ghost">
            查看会员方案
          </Link>
        </div>
      </section>

      {/* 4 功能卡片 */}
      <section className="max-w-6xl mx-auto px-4 pb-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURES.map((f) => (
            <Link
              key={f.to}
              to={f.to}
              className="card p-4 hover:shadow-md hover:-translate-y-0.5 transition group"
            >
              <div
                className={`h-1 -mx-4 -mt-4 mb-3 rounded-t-2xl bg-gradient-to-r ${f.accent}`}
              />
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-slate-900">{f.title}</h3>
                {f.pro && <ProBadge />}
              </div>
              <div className="h-28 mb-3 rounded-xl bg-slate-50 p-3 flex items-center justify-center overflow-hidden">
                {f.preview}
              </div>
              <p className="text-xs text-slate-500">{f.desc}</p>
            </Link>
          ))}
        </div>
      </section>

      {/* 三步闭环 */}
      <section className="max-w-6xl mx-auto px-4 pb-20">
        <h2 className="text-2xl font-bold text-slate-900 text-center mb-10">
          拆解 · 执行 · 沉淀 · 复习
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { n: "01", t: "AI 拆解", d: "输入目标，生成每日任务" },
            { n: "02", t: "学习日", d: "大目标 + 临时任务，今天做啥" },
            { n: "03", t: "复盘洞察", d: "总结原因，未完成池自选" },
            { n: "04", t: "知识复习", d: "沉淀笔记，遗忘曲线提醒" },
          ].map((s) => (
            <div key={s.n} className="card p-5">
              <div className="text-xs font-mono text-brand-500 mb-2">
                {s.n}
              </div>
              <div className="font-semibold text-slate-900">{s.t}</div>
              <div className="text-sm text-slate-500 mt-1">{s.d}</div>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 pb-20">
        <div className="rounded-3xl bg-gradient-to-br from-brand-500 to-brand-700 p-10 text-center text-white">
          <h2 className="text-2xl md:text-3xl font-bold">
            准备好开启你的下一段旅程了吗？
          </h2>
          <p className="mt-3 text-brand-50">
            不用再翻几十篇攻略，3 秒生成专属执行计划。
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link
              to="/schedule"
              className="inline-flex items-center justify-center rounded-xl bg-white px-6 py-3 text-brand-600 font-semibold shadow-lg hover:bg-brand-50 transition"
            >
              进入学习日
            </Link>
            <Link
              to="/planner"
              className="inline-flex items-center justify-center rounded-xl border border-white/40 px-6 py-3 text-white font-semibold hover:bg-white/10 transition"
            >
              拆解我的目标
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
