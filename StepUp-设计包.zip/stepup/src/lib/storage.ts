import type {
  Achievement,
  BacklogItem,
  Plan,
  ReviewLog,
  TaskItem,
  Workspace,
} from "../types/plan";
import { FREE_ACTIVE_GOAL_LIMIT } from "../types/plan";

const KEY_PLAN_LEGACY = "stepup.plan";
const KEY_WORKSPACE = "stepup.workspace";
const KEY_REVIEWS = "stepup.reviews";
const KEY_BACKLOG = "stepup.backlog";
const KEY_PRO = "stepup.pro";
const KEY_BACKLOG_PROMPT = "stepup.backlogPromptDate";
const VERSION = 3;

type WorkspaceEnvelope = { v: number; workspace: Workspace };
type ReviewsEnvelope = { v: number; reviews: ReviewLog[] };
type BacklogEnvelope = { v: number; items: BacklogItem[] };
type LegacyPlanEnvelope = { v: number; plan: Plan | null };

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/** 本地日期字符串 YYYY-MM-DD（修复 UTC 时区 bug） */
function localDateStr(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function todayStr(): string {
  return localDateStr(new Date());
}

export function uid(): string {
  return (
    Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4)
  );
}

export function emptyWorkspace(): Workspace {
  return { plans: [], activePlanId: null, adhocTasks: [] };
}

/** 加载工作区；自动迁移旧版单 plan */
export function loadWorkspace(): Workspace {
  const env = safeParse<WorkspaceEnvelope | null>(
    localStorage.getItem(KEY_WORKSPACE),
    null
  );
  if (env?.workspace) {
    return {
      plans: env.workspace.plans ?? [],
      activePlanId: env.workspace.activePlanId ?? null,
      adhocTasks: env.workspace.adhocTasks ?? [],
    };
  }

  // 迁移旧 stepup.plan
  const legacy = safeParse<LegacyPlanEnvelope | null>(
    localStorage.getItem(KEY_PLAN_LEGACY),
    null
  );
  if (legacy?.plan) {
    const plan = {
      ...legacy.plan,
      status: legacy.plan.status ?? ("active" as const),
      tasks: legacy.plan.tasks.map((t) => ({
        ...t,
        source: t.source ?? ("goal" as const),
        goalId: t.goalId ?? legacy.plan!.id,
      })),
    };
    const ws: Workspace = {
      plans: [plan],
      activePlanId: plan.id,
      adhocTasks: [],
    };
    saveWorkspace(ws);
    return ws;
  }

  return emptyWorkspace();
}

export function saveWorkspace(ws: Workspace): void {
  const env: WorkspaceEnvelope = { v: VERSION, workspace: ws };
  localStorage.setItem(KEY_WORKSPACE, JSON.stringify(env));
}

/** @deprecated 兼容旧调用：返回当前激活的 plan */
export function loadPlan(): Plan | null {
  const ws = loadWorkspace();
  if (ws.activePlanId) {
    return ws.plans.find((p) => p.id === ws.activePlanId) ?? ws.plans[0] ?? null;
  }
  return ws.plans[0] ?? null;
}

/** @deprecated 兼容旧调用：更新当前激活 plan */
export function savePlan(plan: Plan | null): void {
  const ws = loadWorkspace();
  if (!plan) {
    if (ws.activePlanId) {
      ws.plans = ws.plans.filter((p) => p.id !== ws.activePlanId);
      ws.activePlanId = ws.plans[0]?.id ?? null;
    }
    saveWorkspace(ws);
    return;
  }
  const idx = ws.plans.findIndex((p) => p.id === plan.id);
  if (idx >= 0) {
    ws.plans[idx] = plan;
  } else {
    ws.plans.push(plan);
  }
  ws.activePlanId = plan.id;
  saveWorkspace(ws);
}

export function getActivePlans(ws?: Workspace): Plan[] {
  const w = ws ?? loadWorkspace();
  return w.plans.filter((p) => (p.status ?? "active") === "active");
}

export function canAddActiveGoal(ws?: Workspace): boolean {
  if (isProUnlocked()) return true;
  const active = getActivePlans(ws);
  return active.length < FREE_ACTIVE_GOAL_LIMIT;
}

export function upsertPlan(plan: Plan): Workspace {
  const ws = loadWorkspace();
  const idx = ws.plans.findIndex((p) => p.id === plan.id);
  if (idx >= 0) {
    ws.plans[idx] = plan;
  } else {
    ws.plans.push(plan);
  }
  ws.activePlanId = plan.id;
  saveWorkspace(ws);
  return ws;
}

export function setActivePlanId(planId: string): Workspace {
  const ws = loadWorkspace();
  if (ws.plans.some((p) => p.id === planId)) {
    ws.activePlanId = planId;
    saveWorkspace(ws);
  }
  return ws;
}

export function removePlan(planId: string): Workspace {
  const ws = loadWorkspace();
  ws.plans = ws.plans.filter((p) => p.id !== planId);
  if (ws.activePlanId === planId) {
    ws.activePlanId = ws.plans[0]?.id ?? null;
  }
  saveWorkspace(ws);
  return ws;
}

export function setPlanStatus(
  planId: string,
  status: Plan["status"]
): Workspace {
  const ws = loadWorkspace();
  ws.plans = ws.plans.map((p) =>
    p.id === planId ? { ...p, status } : p
  );
  saveWorkspace(ws);
  return ws;
}

/** 所有任务（各目标 + 临时）扁平化，带 goalTitle */
export type DayTask = TaskItem & { goalTitle?: string };

export function getAllTasks(ws?: Workspace): DayTask[] {
  const w = ws ?? loadWorkspace();
  const fromGoals: DayTask[] = w.plans.flatMap((p) =>
    p.tasks.map((t) => ({
      ...t,
      source: t.source ?? "goal",
      goalId: t.goalId ?? p.id,
      goalTitle: p.goal,
    }))
  );
  const fromAdhoc: DayTask[] = w.adhocTasks.map((t) => ({
    ...t,
    source: "adhoc" as const,
    goalTitle: undefined,
  }));
  return [...fromGoals, ...fromAdhoc];
}

export function getTodayTasksFromWorkspace(ws?: Workspace): DayTask[] {
  const today = todayStr();
  const deferredIds = new Set(
    getPendingBacklog()
      .filter((b) => b.sourceDate === today)
      .map((b) => b.taskId)
  );
  return getAllTasks(ws).filter(
    (t) => t.date === today && !deferredIds.has(t.id)
  );
}

export function getTomorrowTasksFromWorkspace(ws?: Workspace): DayTask[] {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  const tomorrow = localDateStr(d);
  return getAllTasks(ws).filter((t) => t.date === tomorrow && !t.completed);
}

/** 更新任意任务（在某 plan 或 adhoc 中） */
export function updateTaskEverywhere(
  taskId: string,
  patch: Partial<TaskItem>
): Workspace {
  const ws = loadWorkspace();
  let found = false;
  ws.plans = ws.plans.map((p) => {
    const idx = p.tasks.findIndex((t) => t.id === taskId);
    if (idx < 0) return p;
    found = true;
    const tasks = [...p.tasks];
    tasks[idx] = { ...tasks[idx], ...patch };
    return { ...p, tasks };
  });
  if (!found) {
    ws.adhocTasks = ws.adhocTasks.map((t) =>
      t.id === taskId ? { ...t, ...patch } : t
    );
  }
  saveWorkspace(ws);
  return ws;
}

export function addAdhocTask(input: {
  title: string;
  suggestedMinutes?: number;
  description?: string;
  goalId?: string; // 可选挂到某目标
}): Workspace {
  const ws = loadWorkspace();
  const today = todayStr();
  const task: TaskItem = {
    id: uid(),
    date: today,
    title: input.title.trim(),
    description: input.description?.trim() ?? "",
    suggestedMinutes: input.suggestedMinutes ?? 30,
    priority: "medium",
    completed: false,
    focusSeconds: 0,
    source: input.goalId ? "goal" : "adhoc",
    goalId: input.goalId,
  };

  if (input.goalId) {
    const plan = ws.plans.find((p) => p.id === input.goalId);
    if (plan) {
      plan.tasks = [...plan.tasks, { ...task, source: "goal" }];
      saveWorkspace(ws);
      return ws;
    }
  }

  ws.adhocTasks = [...ws.adhocTasks, { ...task, source: "adhoc", goalId: undefined }];
  saveWorkspace(ws);
  return ws;
}

export function loadReviews(): ReviewLog[] {
  const env = safeParse<ReviewsEnvelope | null>(
    localStorage.getItem(KEY_REVIEWS),
    null
  );
  return env?.reviews ?? [];
}

export function saveReviews(reviews: ReviewLog[]): void {
  const env: ReviewsEnvelope = { v: VERSION, reviews };
  localStorage.setItem(KEY_REVIEWS, JSON.stringify(env));
}

export function appendReview(review: ReviewLog): void {
  const reviews = loadReviews();
  const filtered = reviews.filter(
    (r) => !(r.date === review.date && r.action === review.action)
  );
  filtered.push(review);
  saveReviews(filtered);
}

export function loadBacklog(): BacklogItem[] {
  const env = safeParse<BacklogEnvelope | null>(
    localStorage.getItem(KEY_BACKLOG),
    null
  );
  return env?.items ?? [];
}

export function saveBacklog(items: BacklogItem[]): void {
  const env: BacklogEnvelope = { v: VERSION, items };
  localStorage.setItem(KEY_BACKLOG, JSON.stringify(env));
}

export function getPendingBacklog(): BacklogItem[] {
  return loadBacklog().filter((b) => b.status === "pending");
}

export function pushUnfinishedToBacklog(
  unfinished: DayTask[],
  reason: BacklogItem["reason"],
  note?: string
): BacklogItem[] {
  const existing = loadBacklog();
  const today = todayStr();
  const existingTaskIds = new Set(
    existing.filter((b) => b.status === "pending").map((b) => b.taskId)
  );

  const created: BacklogItem[] = unfinished
    .filter((t) => !existingTaskIds.has(t.id))
    .map((t) => ({
      id: uid(),
      taskId: t.id,
      title: t.title,
      description: t.description,
      suggestedMinutes: t.suggestedMinutes,
      priority: t.priority,
      goalId: t.goalId,
      goalTitle: t.goalTitle,
      subGoal: t.subGoal,
      source: t.source ?? (t.goalId ? "goal" : "adhoc"),
      originalDate: t.date,
      sourceDate: today,
      reason,
      note,
      status: "pending" as const,
      createdAt: new Date().toISOString(),
    }));

  const next = [...existing, ...created];
  saveBacklog(next);
  return created;
}

/** 将 backlog 项加入今日（写回原 plan 或 adhoc） */
export function addBacklogItemToToday(backlogId: string): Workspace {
  const ws = loadWorkspace();
  const items = loadBacklog();
  const item = items.find((b) => b.id === backlogId);
  if (!item || item.status !== "pending") return ws;

  const today = todayStr();
  const patch: Partial<TaskItem> = {
    date: today,
    completed: false,
    fromBacklog: true,
  };

  let found = false;
  if (item.goalId) {
    ws.plans = ws.plans.map((p) => {
      if (p.id !== item.goalId) return p;
      const idx = p.tasks.findIndex((t) => t.id === item.taskId);
      if (idx >= 0) {
        found = true;
        const tasks = [...p.tasks];
        tasks[idx] = { ...tasks[idx], ...patch };
        return { ...p, tasks };
      }
      found = true;
      return {
        ...p,
        tasks: [
          ...p.tasks,
          {
            id: item.taskId,
            date: today,
            title: item.title,
            description: item.description,
            suggestedMinutes: item.suggestedMinutes,
            priority: item.priority,
            completed: false,
            focusSeconds: 0,
            source: "goal" as const,
            goalId: item.goalId,
            subGoal: item.subGoal,
            fromBacklog: true,
          },
        ],
      };
    });
  }

  if (!found) {
    const aidx = ws.adhocTasks.findIndex((t) => t.id === item.taskId);
    if (aidx >= 0) {
      ws.adhocTasks[aidx] = { ...ws.adhocTasks[aidx], ...patch };
    } else {
      ws.adhocTasks.push({
        id: item.taskId,
        date: today,
        title: item.title,
        description: item.description,
        suggestedMinutes: item.suggestedMinutes,
        priority: item.priority,
        completed: false,
        focusSeconds: 0,
        source: "adhoc",
        fromBacklog: true,
      });
    }
  }

  saveWorkspace(ws);
  saveBacklog(
    items.map((b) =>
      b.id === backlogId ? { ...b, status: "added" as const } : b
    )
  );
  return ws;
}

export function cancelBacklogItem(backlogId: string): void {
  const items = loadBacklog();
  saveBacklog(
    items.map((b) =>
      b.id === backlogId ? { ...b, status: "cancelled" as const } : b
    )
  );
}

export function getBacklogPromptDate(): string | null {
  return localStorage.getItem(KEY_BACKLOG_PROMPT);
}

export function setBacklogPromptDate(date: string): void {
  localStorage.setItem(KEY_BACKLOG_PROMPT, date);
}

// ===== Pro 会员与试用期 =====
const KEY_PRO_TRIAL_START = "stepup.proTrialStart";
const TRIAL_DAYS = 7;

export function isProUnlocked(): boolean {
  if (localStorage.getItem(KEY_PRO) !== "true") return false;
  // 检查试用期是否过期
  const trialStart = localStorage.getItem(KEY_PRO_TRIAL_START);
  if (trialStart) {
    const elapsed = Date.now() - new Date(trialStart).getTime();
    if (elapsed > TRIAL_DAYS * 86_400_000) {
      // 试用过期，自动降级
      localStorage.setItem(KEY_PRO, "false");
      localStorage.removeItem(KEY_PRO_TRIAL_START);
      return false;
    }
  }
  return true;
}

export function setProUnlocked(value: boolean): void {
  localStorage.setItem(KEY_PRO, value ? "true" : "false");
  if (value) {
    if (!localStorage.getItem(KEY_PRO_TRIAL_START)) {
      localStorage.setItem(KEY_PRO_TRIAL_START, new Date().toISOString());
    }
  } else {
    localStorage.removeItem(KEY_PRO_TRIAL_START);
  }
}

export function getTrialInfo(): { active: boolean; daysRemaining: number } {
  if (localStorage.getItem(KEY_PRO) !== "true")
    return { active: false, daysRemaining: 0 };
  const trialStart = localStorage.getItem(KEY_PRO_TRIAL_START);
  if (!trialStart) return { active: true, daysRemaining: TRIAL_DAYS };
  const remaining =
    TRIAL_DAYS * 86_400_000 - (Date.now() - new Date(trialStart).getTime());
  if (remaining <= 0) return { active: false, daysRemaining: 0 };
  return { active: true, daysRemaining: Math.ceil(remaining / 86_400_000) };
}

// ===== Freemium AI 调用次数限制 =====
const KEY_AI_COUNTS = "stepup.aiCounts";
export const FREE_DECOMPOSE_LIMIT = 3;
export const FREE_REPLAN_LIMIT = 1;

type AiCounts = { date: string; decompose: number; replan: number };

function getAiCounts(): AiCounts {
  const today = todayStr();
  const raw = safeParse<AiCounts | null>(
    localStorage.getItem(KEY_AI_COUNTS),
    null
  );
  if (!raw || raw.date !== today)
    return { date: today, decompose: 0, replan: 0 };
  return raw;
}

function saveAiCounts(counts: AiCounts): void {
  localStorage.setItem(KEY_AI_COUNTS, JSON.stringify(counts));
}

export function getAiUsage() {
  const counts = getAiCounts();
  const pro = isProUnlocked();
  return {
    decomposeUsed: counts.decompose,
    decomposeRemaining: pro
      ? Infinity
      : Math.max(0, FREE_DECOMPOSE_LIMIT - counts.decompose),
    replanUsed: counts.replan,
    replanRemaining: pro
      ? Infinity
      : Math.max(0, FREE_REPLAN_LIMIT - counts.replan),
  };
}

export function canDecompose(): boolean {
  if (isProUnlocked()) return true;
  return getAiCounts().decompose < FREE_DECOMPOSE_LIMIT;
}

export function canReplan(): boolean {
  if (isProUnlocked()) return true;
  return getAiCounts().replan < FREE_REPLAN_LIMIT;
}

export function incrementDecomposeCount(): void {
  const c = getAiCounts();
  c.decompose++;
  saveAiCounts(c);
}

export function incrementReplanCount(): void {
  const c = getAiCounts();
  c.replan++;
  saveAiCounts(c);
}

export function getProgress(plan: Plan): number {
  if (plan.tasks.length === 0) return 0;
  const done = plan.tasks.filter((t) => t.completed).length;
  return done / plan.tasks.length;
}

export function getOverallProgress(ws?: Workspace): number {
  const tasks = getAllTasks(ws);
  if (tasks.length === 0) return 0;
  return tasks.filter((t) => t.completed).length / tasks.length;
}

/** @deprecated 单 plan 今日任务 */
export function getTodayTasks(plan: Plan): TaskItem[] {
  const today = todayStr();
  return plan.tasks.filter((t) => t.date === today);
}

export function getTomorrowTasks(plan: Plan): TaskItem[] {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  const tomorrow = localDateStr(d);
  return plan.tasks.filter((t) => t.date === tomorrow && !t.completed);
}

export function computeAchievement(
  wsOrPlan: Workspace | Plan | null,
  reviews: ReviewLog[]
): Achievement {
  let totalFocusMinutes = 0;
  let progress = 0;

  if (wsOrPlan && "plans" in wsOrPlan) {
    const tasks = getAllTasks(wsOrPlan);
    totalFocusMinutes = Math.round(
      tasks.reduce((sum, t) => sum + t.focusSeconds, 0) / 60
    );
    progress = getOverallProgress(wsOrPlan);
  } else if (wsOrPlan) {
    totalFocusMinutes = Math.round(
      wsOrPlan.tasks.reduce((sum, t) => sum + t.focusSeconds, 0) / 60
    );
    progress = getProgress(wsOrPlan);
  }

  // streak 只计 completedCount > 0 的日期（纯 skip 不计入）
  const actionDates = new Set(
    reviews
      .filter((r) => r.completedCount > 0)
      .map((r) => r.date)
  );

  let streakDays = 0;
  if (actionDates.size > 0) {
    const d = new Date();
    if (!actionDates.has(todayStr())) {
      d.setDate(d.getDate() - 1);
    }
    while (actionDates.has(localDateStr(d))) {
      streakDays += 1;
      d.setDate(d.getDate() - 1);
    }
  }

  return {
    totalFocusMinutes,
    streakDays,
    milestone25: progress >= 0.25,
    milestone50: progress >= 0.5,
    milestone100: progress >= 1,
  };
}

export function getTimerSeconds(taskId: string): number {
  try {
    const all = JSON.parse(
      localStorage.getItem("stepup.timer") || "{}"
    ) as Record<
      string,
      { accumulatedSeconds?: number; startedAt?: number | null; state?: string }
    >;
    const p = all[taskId];
    if (!p) return 0;
    let sec = p.accumulatedSeconds ?? 0;
    if (p.state === "running" && p.startedAt) {
      sec += Math.floor((Date.now() - p.startedAt) / 1000);
    }
    return Math.max(0, sec);
  } catch {
    return 0;
  }
}

export function syncFocusFromTimers(ws?: Workspace): Workspace {
  const base = ws ?? loadWorkspace();
  const w: Workspace = {
    activePlanId: base.activePlanId,
    plans: base.plans.map((p) => ({
      ...p,
      tasks: p.tasks.map((t) => ({
        ...t,
        focusSeconds: Math.max(t.focusSeconds, getTimerSeconds(t.id)),
      })),
    })),
    adhocTasks: base.adhocTasks.map((t) => ({
      ...t,
      focusSeconds: Math.max(t.focusSeconds, getTimerSeconds(t.id)),
    })),
  };
  saveWorkspace(w);
  return w;
}

/** 兼容旧 syncFocusFromTimers(plan) 签名：若传入 Plan，仍更新 workspace 中该 plan */
export function syncFocusFromTimersPlan(plan: Plan): Plan {
  const ws = syncFocusFromTimers();
  return ws.plans.find((p) => p.id === plan.id) ?? plan;
}

export function buildEncouragement(
  completedCount: number,
  totalCount: number,
  focusMinutes: number,
  streakDays: number
): string {
  if (totalCount === 0) return "先去规划今天的任务吧。";
  if (completedCount === totalCount && totalCount > 0) {
    if (streakDays >= 7) {
      return `今日 ${completedCount} 项全部完成，专注 ${focusMinutes} 分钟。你已连续行动 ${streakDays} 天，节奏很稳。`;
    }
    return `今日 ${completedCount} 项全部完成，专注 ${focusMinutes} 分钟。把大目标拆成今天做得到的小事，你做到了。`;
  }
  const rate = Math.round((completedCount / totalCount) * 100);
  if (rate >= 60) {
    return `今天完成了 ${completedCount}/${totalCount}（${rate}%），专注 ${focusMinutes} 分钟。未完成的已放进待办池，明天由你决定是否继续。`;
  }
  return `今天完成了 ${completedCount}/${totalCount}。没做完没关系，未完成已记录，明天你可以选择加入或先放着。`;
}
