import { useState } from "react";
import type { TaskItem } from "../types/plan";
import { useTaskTimer, formatTime } from "../hooks/useTaskTimer";

type Props = {
  task: TaskItem;
  onToggleComplete: (id: string) => void;
  onEdit: (id: string, patch: Partial<TaskItem>) => void;
  /** 学习日展示：所属目标名或「临时」 */
  goalLabel?: string;
};

const PRIORITY_STYLE: Record<string, string> = {
  high: "bg-rose-50 text-rose-600",
  medium: "bg-amber-50 text-amber-600",
  low: "bg-emerald-50 text-emerald-600",
};

const PRIORITY_LABEL: Record<string, string> = {
  high: "高",
  medium: "中",
  low: "低",
};

export default function TaskCard({
  task,
  onToggleComplete,
  onEdit,
  goalLabel,
}: Props) {
  const [editing, setEditing] = useState(false);
  const [titleDraft, setTitleDraft] = useState(task.title);
  const [minutesDraft, setMinutesDraft] = useState(
    String(task.suggestedMinutes)
  );
  const [mode, setMode] = useState<"countup" | "countdown">("countup");
  const [countdownMin, setCountdownMin] = useState(task.suggestedMinutes);

  const timer = useTaskTimer(task.id, task.focusSeconds);

  const handleStart = () => {
    if (mode === "countdown") {
      timer.start(countdownMin * 60);
    } else {
      timer.start(null);
    }
  };

  const handleSaveEdit = () => {
    const mins = Number(minutesDraft);
    if (!Number.isNaN(mins) && mins > 0) {
      onEdit(task.id, {
        title: titleDraft.trim() || task.title,
        suggestedMinutes: mins,
      });
      setCountdownMin(mins);
    }
    setEditing(false);
  };

  return (
    <div
      className={`card p-4 transition ${
        task.completed ? "opacity-60" : ""
      }`}
    >
      <div className="flex items-start gap-3">
        <button
          onClick={() => onToggleComplete(task.id)}
          className={`mt-1 w-5 h-5 rounded-md border-2 flex items-center justify-center transition ${
            task.completed
              ? "bg-emerald-500 border-emerald-500 text-white"
              : "border-slate-300 hover:border-brand-400"
          }`}
          aria-label="完成"
        >
          {task.completed && (
            <svg viewBox="0 0 20 20" fill="currentColor" className="w-3 h-3">
              <path
                fillRule="evenodd"
                d="M16.7 5.3a1 1 0 010 1.4l-7.5 7.5a1 1 0 01-1.4 0L3.3 9.7a1 1 0 011.4-1.4l3.3 3.3 6.8-6.8a1 1 0 011.4 0z"
                clipRule="evenodd"
              />
            </svg>
          )}
        </button>

        <div className="flex-1 min-w-0">
          {editing ? (
            <div className="space-y-2">
              <input
                className="input-field text-sm"
                value={titleDraft}
                onChange={(e) => setTitleDraft(e.target.value)}
              />
              <div className="flex items-center gap-2">
                <label className="text-xs text-slate-500">建议分钟</label>
                <input
                  type="number"
                  min={1}
                  className="input-field text-sm w-24"
                  value={minutesDraft}
                  onChange={(e) => setMinutesDraft(e.target.value)}
                />
                <button className="btn-primary text-sm py-1.5" onClick={handleSaveEdit}>
                  保存
                </button>
                <button
                  className="btn-ghost text-sm py-1.5"
                  onClick={() => setEditing(false)}
                >
                  取消
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 flex-wrap">
                <h3
                  className={`font-medium text-slate-900 ${
                    task.completed ? "line-through" : ""
                  }`}
                >
                  {task.title}
                </h3>
                {goalLabel !== undefined && (
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full ${
                      task.source === "adhoc" || !task.goalId
                        ? "bg-slate-100 text-slate-600"
                        : "bg-brand-50 text-brand-600"
                    }`}
                  >
                    {goalLabel || "临时"}
                  </span>
                )}
                {task.fromBacklog && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-50 text-amber-600">
                    补做
                  </span>
                )}
                <span
                  className={`text-xs px-2 py-0.5 rounded-full ${
                    PRIORITY_STYLE[task.priority] ?? PRIORITY_STYLE.low
                  }`}
                >
                  {PRIORITY_LABEL[task.priority] ?? "低"}
                </span>
                <button
                  className="text-xs text-slate-400 hover:text-brand-500"
                  onClick={() => setEditing(true)}
                >
                  编辑
                </button>
              </div>
              {task.description && (
                <p className="text-sm text-slate-500 mt-1">
                  {task.description}
                </p>
              )}
              <div className="text-xs text-slate-400 mt-1">
                建议 {task.suggestedMinutes} 分钟
              </div>
            </>
          )}
        </div>

        <div className="text-right shrink-0">
          <div className="font-mono text-2xl font-semibold text-brand-600 tabular-nums">
            {formatTime(timer.elapsed)}
          </div>
          <div className="text-xs text-slate-400">
            {timer.state === "running"
              ? "专注中"
              : timer.state === "paused"
              ? "已暂停"
              : timer.state === "done"
              ? "已完成"
              : "未开始"}
          </div>
        </div>
      </div>

      {!task.completed && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 overflow-hidden text-xs">
            <button
              className={`px-3 py-1.5 ${
                mode === "countup"
                  ? "bg-brand-500 text-white"
                  : "bg-white text-slate-600"
              }`}
              onClick={() => setMode("countup")}
            >
              正计时
            </button>
            <button
              className={`px-3 py-1.5 ${
                mode === "countdown"
                  ? "bg-brand-500 text-white"
                  : "bg-white text-slate-600"
              }`}
              onClick={() => setMode("countdown")}
            >
              倒计时
            </button>
          </div>
          {mode === "countdown" && (
            <input
              type="number"
              min={1}
              value={countdownMin}
              onChange={(e) =>
                setCountdownMin(Number(e.target.value) || 1)
              }
              className="input-field text-sm w-24 py-1.5"
            />
          )}
          {timer.state === "idle" && (
            <button className="btn-primary text-sm py-1.5" onClick={handleStart}>
              开始专注
            </button>
          )}
          {timer.state === "running" && (
            <button className="btn-ghost text-sm py-1.5" onClick={timer.pause}>
              暂停
            </button>
          )}
          {timer.state === "paused" && (
            <button className="btn-primary text-sm py-1.5" onClick={timer.resume}>
              继续
            </button>
          )}
          {timer.state !== "idle" && (
            <button
              className="text-sm text-slate-400 hover:text-rose-500"
              onClick={timer.stop}
            >
              重置
            </button>
          )}
        </div>
      )}
    </div>
  );
}
