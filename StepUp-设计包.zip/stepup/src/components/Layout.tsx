import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { isProUnlocked } from "../lib/storage";

const NAV = [
  { to: "/", label: "首页" },
  { to: "/schedule", label: "学习日" },
  { to: "/planner", label: "目标规划" },
  { to: "/progress", label: "复盘" },
  { to: "/knowledge", label: "知识库" },
  { to: "/review", label: "复习提醒" },
];

export default function Layout() {
  const location = useLocation();
  const [pro, setPro] = useState<boolean>(false);

  useEffect(() => {
    setPro(isProUnlocked());
  }, [location.pathname]);

  return (
    <div className="min-h-full flex flex-col">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/80 border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-bold">
              S
            </span>
            <span className="font-semibold text-slate-900">StepUp</span>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.to === "/"}
                className={({ isActive }) =>
                  `px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                    isActive
                      ? "bg-brand-50 text-brand-600"
                      : "text-slate-600 hover:text-brand-600 hover:bg-slate-50"
                  }`
                }
              >
                {n.label}
              </NavLink>
            ))}
          </nav>
          <Link
            to="/membership"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium bg-gradient-to-r from-amber-400 to-orange-500 text-white shadow-sm hover:shadow-md transition"
          >
            {pro ? "Pro 已开通" : "升级 Pro"}
          </Link>
        </div>
        <nav className="md:hidden border-t border-slate-100 overflow-x-auto">
          <div className="px-2 flex gap-1 py-1.5">
            {NAV.map((n) => (
              <NavLink
                key={n.to}
                to={n.to}
                end={n.to === "/"}
                className={({ isActive }) =>
                  `px-3 py-1 rounded-md text-xs font-medium whitespace-nowrap ${
                    isActive
                      ? "bg-brand-50 text-brand-600"
                      : "text-slate-600"
                  }`
                }
              >
                {n.label}
              </NavLink>
            ))}
          </div>
        </nav>
      </header>
      <main className="flex-1">
        <Outlet />
      </main>
      <footer className="border-t border-slate-100 bg-white">
        <div className="max-w-6xl mx-auto px-4 py-6 text-sm text-slate-500 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
          <div>© 2026 StepUp · 把大目标，变成今天做得到的小事</div>
          <div className="flex gap-4">
            <Link to="/membership" className="hover:text-brand-600">
              会员
            </Link>
            <a
              href="https://wanderaiai.netlify.app"
              target="_blank"
              rel="noreferrer"
              className="hover:text-brand-600"
            >
              灵感参考
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
