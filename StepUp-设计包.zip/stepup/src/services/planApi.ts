import type {
  DecomposeRequest,
  DecomposeResponse,
  ReplanRequest,
  ReplanResponse,
} from "../types/plan";

async function postJSON<T>(url: string, body: unknown): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30_000);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      throw new Error(`请求失败 (${res.status}): ${text || res.statusText}`);
    }
    return (await res.json()) as T;
  } finally {
    clearTimeout(timer);
  }
}

export async function decomposePlan(
  req: DecomposeRequest
): Promise<DecomposeResponse> {
  return postJSON<DecomposeResponse>("/api/decompose", req);
}

export async function replanPlan(
  req: ReplanRequest
): Promise<ReplanResponse> {
  return postJSON<ReplanResponse>("/api/replan", req);
}
