export type Priority = "high" | "medium" | "low";

export type SkipReason =
  | "too_tired"
  | "no_time"
  | "too_hard"
  | "something_came_up"
  | "other";

export const SKIP_REASON_LABELS: Record<SkipReason, string> = {
  too_tired: "太累了",
  no_time: "时间不够",
  too_hard: "任务太难",
  something_came_up: "临时有事",
  other: "其他",
};

export type TaskSource = "goal" | "adhoc";

export type TaskItem = {
  id: string;
  date: string; // YYYY-MM-DD 安排日期
  title: string;
  description: string;
  suggestedMinutes: number;
  priority: Priority;
  completed: boolean;
  focusSeconds: number;
  /** goal = 来自某大目标；adhoc = 当天临时添加 */
  source?: TaskSource;
  /** 所属大目标 id；临时任务可为空 */
  goalId?: string;
  /** 所属小目标/模块名（可选） */
  subGoal?: string;
  /** 是否从未完成池加入今日 */
  fromBacklog?: boolean;
};

export type Plan = {
  id: string;
  goal: string;
  deadline: string;
  dailyMinutes: number;
  workdays: ("weekday" | "weekend")[];
  createdAt: string;
  tasks: TaskItem[];
  status?: "active" | "paused" | "done";
};

/** 多目标工作区 */
export type Workspace = {
  plans: Plan[];
  /** 规划页当前选中的目标 */
  activePlanId: string | null;
  /** 不挂大目标的临时任务（按 date 排到学习日） */
  adhocTasks: TaskItem[];
};

export type BacklogStatus = "pending" | "cancelled" | "added";

export type BacklogItem = {
  id: string;
  taskId: string;
  title: string;
  description: string;
  suggestedMinutes: number;
  priority: Priority;
  goalId?: string;
  goalTitle?: string;
  subGoal?: string;
  source?: TaskSource;
  originalDate: string;
  sourceDate: string;
  reason: SkipReason;
  note?: string;
  status: BacklogStatus;
  createdAt: string;
};

export type ReviewLog = {
  id: string;
  date: string;
  completedIds: string[];
  unfinishedIds: string[];
  unfinishedTitles: string[];
  reason?: SkipReason;
  difficulty: string;
  focusMinutes: number;
  completedCount: number;
  totalCount: number;
  tomorrowMinutes?: number;
  aiSuggestion?: string;
  action?: "checkin_complete" | "skip_to_backlog" | "manual_note";
};

export type Achievement = {
  totalFocusMinutes: number;
  streakDays: number;
  milestone25: boolean;
  milestone50: boolean;
  milestone100: boolean;
};

export type DecomposeRequest = {
  goal: string;
  deadline: string;
  dailyMinutes: number;
  workdays: string[];
};

export type DecomposeResponse = {
  tasks: Omit<TaskItem, "id" | "completed" | "focusSeconds">[];
  mock?: boolean;
};

export type ReplanRequest = {
  plan: Plan;
  difficulty: string;
  tomorrowMinutes: number;
};

export type ReplanResponse = {
  tasks: Omit<TaskItem, "id" | "completed" | "focusSeconds">[];
  suggestion: string;
  mock?: boolean;
};

/** 免费版最多 1 个进行中大目标；Pro 不限 */
export const FREE_ACTIVE_GOAL_LIMIT = 1;
