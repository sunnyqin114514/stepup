import { useCallback, useEffect, useRef, useState } from "react";

type TimerState = "idle" | "running" | "paused" | "done";

type Persisted = {
  state: TimerState;
  startedAt: number | null; // 上次启动的时间戳
  accumulatedSeconds: number; // 已累计秒数
  targetSeconds: number | null; // 倒计时目标，null 表示正计时
};

const STORAGE_KEY = "stepup.timer";

function loadAll(): Record<string, Persisted> {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

function saveOne(taskId: string, p: Persisted) {
  const all = loadAll();
  all[taskId] = p;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

function removeOne(taskId: string) {
  const all = loadAll();
  delete all[taskId];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export function useTaskTimer(taskId: string, initialSeconds: number = 0) {
  const [state, setState] = useState<TimerState>("idle");
  const [elapsed, setElapsed] = useState<number>(initialSeconds);
  const [target, setTarget] = useState<number | null>(null);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const tickRef = useRef<number | null>(null);

  // 初始化：从 localStorage 恢复
  useEffect(() => {
    const all = loadAll();
    const p = all[taskId];
    if (p) {
      setState(p.state);
      setElapsed(p.accumulatedSeconds);
      setTarget(p.targetSeconds);
      setStartedAt(p.startedAt);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [taskId]);

  // tick 循环
  useEffect(() => {
    if (state !== "running" || startedAt === null) return;
    const tick = () => {
      const now = Date.now();
      const added = Math.floor((now - (startedAt ?? now)) / 1000);
      const total = (loadAll()[taskId]?.accumulatedSeconds ?? 0) + added;
      setElapsed(total);
      if (target !== null && total >= target) {
        setState("done");
        setElapsed(target);
      }
    };
    tick();
    tickRef.current = window.setInterval(tick, 1000);
    return () => {
      if (tickRef.current) window.clearInterval(tickRef.current);
    };
  }, [state, startedAt, target, taskId]);

  // 持久化
  useEffect(() => {
    if (state === "idle" && elapsed === 0) return;
    saveOne(taskId, {
      state,
      startedAt,
      accumulatedSeconds: elapsed,
      targetSeconds: target,
    });
  }, [state, startedAt, elapsed, target, taskId]);

  const start = useCallback(
    (targetSeconds: number | null = null) => {
      setTarget(targetSeconds);
      setStartedAt(Date.now());
      setState("running");
    },
    []
  );

  const pause = useCallback(() => {
    if (state !== "running") return;
    // 把累计时间固化
    const all = loadAll();
    const p = all[taskId];
    if (p && p.startedAt) {
      const added = Math.floor((Date.now() - p.startedAt) / 1000);
      const newAcc = p.accumulatedSeconds + added;
      saveOne(taskId, {
        ...p,
        state: "paused",
        startedAt: null,
        accumulatedSeconds: newAcc,
      });
      setElapsed(newAcc);
    }
    setStartedAt(null);
    setState("paused");
  }, [state, taskId]);

  const resume = useCallback(() => {
    if (state !== "paused") return;
    setStartedAt(Date.now());
    setState("running");
  }, [state]);

  const stop = useCallback(() => {
    setState("idle");
    setStartedAt(null);
    setElapsed(0);
    setTarget(null);
    removeOne(taskId);
  }, []);

  return {
    state,
    elapsed,
    target,
    start,
    pause,
    resume,
    stop,
  };
}

export function formatTime(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
