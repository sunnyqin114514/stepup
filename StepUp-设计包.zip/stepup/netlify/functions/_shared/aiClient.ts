import OpenAI from "openai";
import dotenv from "dotenv";

// 加载 .env 文件（本地开发用；生产环境由 Netlify 注入）
dotenv.config();

const DEEPSEEK_BASE_URL = "https://api.deepseek.com";
const DEEPSEEK_MODEL = "deepseek-chat";

const NETLIFY_MODEL = "gpt-4o-mini";

export type AiClient = {
  client: OpenAI;
  model: string;
};

// 创建 AI 客户端：
// 1. 优先使用 DEEPSEEK_API_KEY（本地开发用用户自己的 key）
// 2. 否则用默认 OpenAI 构造（部署到 Netlify 后由 AI Gateway 自动注入 key）
export function createAiClient(): AiClient {
  const deepseekKey =
    (typeof Netlify !== "undefined" && Netlify.env?.get?.("DEEPSEEK_API_KEY")) ||
    (typeof process !== "undefined" && process.env?.DEEPSEEK_API_KEY) ||
    undefined;

  if (deepseekKey) {
    return {
      client: new OpenAI({
        apiKey: deepseekKey,
        baseURL: DEEPSEEK_BASE_URL,
      }),
      model: DEEPSEEK_MODEL,
    };
  }

  // 走 Netlify AI Gateway（生产部署后自动激活）
  return {
    client: new OpenAI(),
    model: NETLIFY_MODEL,
  };
}

// ===== Origin 鉴权（防止外部滥用） =====
const DEV_ORIGINS = [
  "http://localhost:5173",
  "http://localhost:4173",
  "http://localhost:3000",
  "http://127.0.0.1:5173",
  "http://127.0.0.1:4173",
  "http://127.0.0.1:3000",
];

export function checkOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return false;
  if (DEV_ORIGINS.includes(origin)) return true;
  // 生产环境：允许 Netlify 部署域名
  if (origin.endsWith(".netlify.app")) return true;
  return false;
}
