import type { Config } from "@netlify/functions";
import type {
  ReplanRequest,
  ReplanResponse,
  TaskItem,
  Priority,
} from "../../src/types/plan";
import { checkOrigin, createAiClient } from "./_shared/aiClient";

function buildPrompt(req: ReplanRequest): string {
  const unfinished = req.plan.tasks.filter((t) => !t.completed);
  return `你是计划重排助手。用户今天复盘如下：

【目标】${req.plan.goal}
【截止日期】${req.plan.deadline}
【今日困难】${req.difficulty || "无"}
【明日可投入时长】${req.tomorrowMinutes} 分钟

【未完成任务（已完成的不需要重排）】
${unfinished
  .map(
    (t) =>
      `- ${t.date} | ${t.title} | 建议${t.suggestedMinutes}分钟 | ${t.priority}`
  )
  .join("\n") || "（无）"}

请基于剩余时间与用户困难，重新安排未完成任务到合适的日期，确保不超过截止日期和每日可投入时长。

严格输出 JSON：
{
  "tasks": [{"date":"YYYY-MM-DD","title":"","description":"","suggestedMinutes":30,"priority":"medium"}],
  "suggestion": "一句鼓励与建议，30字内"
}

只输出 JSON，不要解释。`;
}

function sanitizeTask(raw: unknown): Omit<
  TaskItem,
  "id" | "completed" | "focusSeconds"
> | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const date = String(r.date ?? "");
  const title = String(r.title ?? "").slice(0, 30);
  const description = String(r.description ?? "").slice(0, 80);
  const suggestedMinutes = Number(r.suggestedMinutes) || 30;
  const priorityRaw = String(r.priority ?? "medium");
  const priority: Priority =
    priorityRaw === "high" || priorityRaw === "low"
      ? priorityRaw
      : "medium";
  if (!date || !title) return null;
  return { date, title, description, suggestedMinutes, priority };
}

// ===== Mock 兜底 =====

function generateMockReplan(req: ReplanRequest): {
  tasks: Omit<TaskItem, "id" | "completed" | "focusSeconds">[];
  suggestion: string;
} {
  const unfinished = req.plan.tasks.filter((t) => !t.completed);
  const start = new Date();
  start.setDate(start.getDate() + 1);
  const end = new Date(req.plan.deadline);
  if (Number.isNaN(end.getTime()) || end < start) {
    end.setDate(end.getDate() + 7);
  }

  const days: string[] = [];
  const cursor = new Date(start);
  while (cursor <= end && days.length < 30) {
    days.push(cursor.toISOString().slice(0, 10));
    cursor.setDate(cursor.getDate() + 1);
  }

  const perDay = req.tomorrowMinutes || 120;
  const tasks: Omit<TaskItem, "id" | "completed" | "focusSeconds">[] = unfinished.map(
    (t, i) => ({
      date: days[Math.min(i, days.length - 1)] ?? days[0],
      title: t.title,
      description: t.description,
      suggestedMinutes: Math.min(perDay, t.suggestedMinutes),
      priority: t.priority,
    })
  );

  const suggestions = [
    "已根据你的反馈重新排期，明天继续加油！",
    "困难已被记录，任务节奏已调整，保持节奏即可。",
    "重排完成，记得明天先做高优先级任务。",
    "计划已更新，专注当下，每天进步一点点。",
  ];
  const suggestion = suggestions[Math.floor(Math.random() * suggestions.length)];

  return { tasks, suggestion };
}

export default async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  // Origin 鉴权
  if (!checkOrigin(req)) {
    return new Response("Forbidden", { status: 403 });
  }

  let body: ReplanRequest;
  try {
    body = (await req.json()) as ReplanRequest;
  } catch {
    return Response.json({ error: "无效的请求体" }, { status: 400 });
  }

  if (!body.plan) {
    return Response.json({ error: "缺少计划数据" }, { status: 400 });
  }

  let completion;
  try {
    const { client, model } = createAiClient();
    completion = await client.chat.completions.create({
      model,
      messages: [
        { role: "system", content: "你是计划重排助手，只输出 JSON。" },
        { role: "user", content: buildPrompt(body) },
      ],
      temperature: 0.6,
    });
  } catch (err) {
    console.warn("AI 调用失败，使用 mock 兜底:", err instanceof Error ? err.message : err);
    const mock = generateMockReplan(body);
    return Response.json({ ...mock, mock: true });
  }

  const content = completion.choices?.[0]?.message?.content ?? "";
  let parsed: { tasks?: unknown[]; suggestion?: string };
  try {
    const cleaned = content
      .replace(/^```json\s*/i, "")
      .replace(/^```\s*/i, "")
      .replace(/```$/i, "")
      .trim();
    parsed = JSON.parse(cleaned);
  } catch {
    const mock = generateMockReplan(body);
    return Response.json({ ...mock, mock: true });
  }

  const arr = Array.isArray(parsed.tasks) ? parsed.tasks : [];
  const tasks = arr
    .map(sanitizeTask)
    .filter((t): t is NonNullable<typeof t> => t !== null);

  if (tasks.length === 0) {
    const mock = generateMockReplan(body);
    return Response.json({ ...mock, mock: true });
  }

  const result: ReplanResponse = {
    tasks,
    suggestion: String(parsed.suggestion ?? "已为你重新安排，继续加油！").slice(0, 60),
  };
  return Response.json(result);
};

export const config: Config = {
  path: "/api/replan",
  method: "POST",
};
