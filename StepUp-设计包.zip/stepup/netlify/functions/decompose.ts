import type { Config } from "@netlify/functions";
import type {
  DecomposeRequest,
  DecomposeResponse,
  TaskItem,
  Priority,
} from "../../src/types/plan";
import { checkOrigin, createAiClient } from "./_shared/aiClient";

function buildPrompt(req: DecomposeRequest): string {
  return `你是一个目标拆解专家。请把用户的大目标拆解为按天排列的具体可执行任务。

【用户目标】${req.goal}
【截止日期】${req.deadline}
【每天可投入时长】${req.dailyMinutes} 分钟
【可执行日】${req.workdays.join("、")}

要求：
1. 严格输出 JSON 数组，每个元素包含字段：date(YYYY-MM-DD), title(任务标题, 12字内), description(说明, 30字内), suggestedMinutes(建议分钟数, 不超过每日可投入时长), priority("high"|"medium"|"low")
2. 任务总数控制在 5 到 20 之间
3. 每日所有任务的 suggestedMinutes 之和不得超过每日可投入时长的 90%（预留 10% 缓冲，防止认知超载）
4. 不要输出任何解释文字，只输出 JSON 数组

示例输出：
[{"date":"2026-07-18","title":"通读考研大纲","description":"了解考试结构与重点","suggestedMinutes":60,"priority":"high"}]`;
}

function sanitizeTask(raw: unknown): Omit<
  TaskItem,
  "id" | "completed" | "focusSeconds"
> | null {
  if (!raw || typeof raw !== "object") return null;
  const r = raw as Record<string, unknown>;
  const date = String(r.date ?? "");
  const title = String(r.title ?? "").slice(0, 30);
  const description = String(r.description ?? "").slice(0, 80);
  const suggestedMinutes = Number(r.suggestedMinutes) || 30;
  const priorityRaw = String(r.priority ?? "medium");
  const priority: Priority =
    priorityRaw === "high" || priorityRaw === "low"
      ? priorityRaw
      : "medium";
  if (!date || !title) return null;
  return { date, title, description, suggestedMinutes, priority };
}

// ===== Mock 兜底：AI Gateway 未激活时使用 =====

const MOCK_TEMPLATES: { title: string; desc: string; priority: Priority }[] = [
  { title: "通读大纲与目标拆解", desc: "了解整体结构与重点章节", priority: "high" },
  { title: "基础概念梳理", desc: "建立知识框架，标记薄弱点", priority: "high" },
  { title: "核心知识点精读", desc: "逐节学习并做笔记", priority: "medium" },
  { title: "配套练习巩固", desc: "完成对应章节习题", priority: "medium" },
  { title: "错题整理与复盘", desc: "归纳易错点，形成错题本", priority: "high" },
  { title: "专项突破训练", desc: "针对薄弱环节强化", priority: "medium" },
  { title: "阶段性小测", desc: "检验阶段性学习效果", priority: "medium" },
  { title: "综合真题演练", desc: "按真实考试节奏做题", priority: "high" },
  { title: "查漏补缺回顾", desc: "回顾错题与薄弱点", priority: "medium" },
  { title: "模拟考试 1", desc: "完整模拟一次考试流程", priority: "high" },
  { title: "模拟考试 2", desc: "提升应试节奏感", priority: "high" },
  { title: "考前冲刺记忆", desc: "高频考点集中背诵", priority: "high" },
  { title: "心态调整与休息", desc: "保持节奏，调整状态", priority: "low" },
  { title: "最终回顾与总结", desc: "通读笔记与错题", priority: "medium" },
];

function generateMockTasks(req: DecomposeRequest): Omit<
  TaskItem,
  "id" | "completed" | "focusSeconds"
>[] {
  const start = new Date();
  const end = new Date(req.deadline);
  if (Number.isNaN(end.getTime())) {
    end.setDate(end.getDate() + 30);
  }
  const days: string[] = [];
  const cursor = new Date(start);
  while (cursor <= end && days.length < 60) {
    const dow = cursor.getDay(); // 0 周日, 6 周六
    const isWeekday = dow >= 1 && dow <= 5;
    const isWeekend = dow === 0 || dow === 6;
    const ok =
      (req.workdays.includes("weekday") && isWeekday) ||
      (req.workdays.includes("weekend") && isWeekend);
    if (ok) days.push(cursor.toISOString().slice(0, 10));
    cursor.setDate(cursor.getDate() + 1);
  }

  // 任务总数：天数较多时取 10-14 条，少时按天数
  const count = Math.min(MOCK_TEMPLATES.length, Math.max(5, Math.min(14, Math.ceil(days.length * 0.6))));

  const perDayMinutes = req.dailyMinutes || 120;
  const tasks: Omit<TaskItem, "id" | "completed" | "focusSeconds">[] = [];
  for (let i = 0; i < count; i++) {
    const tpl = MOCK_TEMPLATES[i % MOCK_TEMPLATES.length];
    const date = days[Math.floor((i / count) * days.length)] ?? days[0];
    // 每条任务占每日可投入时长的 50%-100%
    const minutes = Math.min(
      perDayMinutes,
      Math.max(30, Math.round(perDayMinutes * (0.5 + (i % 3) * 0.15)))
    );
    tasks.push({
      date,
      title: tpl.title,
      description: tpl.desc,
      suggestedMinutes: minutes,
      priority: tpl.priority,
    });
  }
  return tasks;
}

export default async (req: Request): Promise<Response> => {
  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  // Origin 鉴权
  if (!checkOrigin(req)) {
    return new Response("Forbidden", { status: 403 });
  }

  let body: DecomposeRequest;
  try {
    body = (await req.json()) as DecomposeRequest;
  } catch {
    return Response.json({ error: "无效的请求体" }, { status: 400 });
  }

  if (!body.goal?.trim() || !body.deadline) {
    return Response.json(
      { error: "目标和截止日期必填" },
      { status: 400 }
    );
  }

  let completion;
  try {
    const { client, model } = createAiClient();
    completion = await client.chat.completions.create({
      model,
      messages: [
        { role: "system", content: "你是任务拆解助手，只输出 JSON。" },
        { role: "user", content: buildPrompt(body) },
      ],
      temperature: 0.6,
    });
  } catch (err) {
    // AI Gateway 未激活或调用失败 → 走 mock 兜底
    console.warn("AI 调用失败，使用 mock 兜底:", err instanceof Error ? err.message : err);
    const mockTasks = generateMockTasks(body);
    return Response.json({ tasks: mockTasks, mock: true });
  }

  const content = completion.choices?.[0]?.message?.content ?? "";
  let parsed: unknown;
  try {
    const cleaned = content
      .replace(/^```json\s*/i, "")
      .replace(/^```\s*/i, "")
      .replace(/```$/i, "")
      .trim();
    parsed = JSON.parse(cleaned);
  } catch {
    // AI 返回格式异常 → 走 mock 兜底
    const mockTasks = generateMockTasks(body);
    return Response.json({ tasks: mockTasks, mock: true });
  }

  const arr = Array.isArray(parsed) ? parsed : [];
  const tasks = arr
    .map(sanitizeTask)
    .filter((t): t is NonNullable<typeof t> => t !== null);

  if (tasks.length === 0) {
    const mockTasks = generateMockTasks(body);
    return Response.json({ tasks: mockTasks, mock: true });
  }

  // 服务端校验：每日总时长 ≤ dailyMinutes × 90%（防止认知超载）
  const dailyBudget = Math.round((body.dailyMinutes || 120) * 0.9);
  const dailyUsed: Record<string, number> = {};
  const cappedTasks = tasks.map((t) => {
    const used = dailyUsed[t.date] ?? 0;
    const allowed = Math.max(15, dailyBudget - used);
    const minutes = Math.min(t.suggestedMinutes, allowed);
    dailyUsed[t.date] = used + minutes;
    return { ...t, suggestedMinutes: minutes };
  });

  const result: DecomposeResponse = { tasks: cappedTasks };
  return Response.json(result);
};

export const config: Config = {
  path: "/api/decompose",
  method: "POST",
};
